# Cleanfolio Minimal

A portfolio template built with HTML, CSS, and JavaScript.

## Preview

[![imgur](https://i.imgur.com/5z7cvMz.gif)](https://rajshekhar26.github.io/cleanfolio-minimal)

[Live Demo](https://rajshekhar26.github.io/cleanfolio-minimal)

## License

[MIT](https://choosealicense.com/licenses/mit/)
